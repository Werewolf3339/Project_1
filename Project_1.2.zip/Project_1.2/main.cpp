/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on April 22, 2016, 1:14 PM
 * Purpose: Adventure through a dungeon and collect the loot
 */

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <string>
#include <iomanip>

using namespace std;

int prof(), random(int chance);
bool room2(int classnum), room3(int classnum);
void intro1(int classnum), youlive(), room1(int classnum), youdied(),
        winners();

//functions for class selection, randomizing, room 2, room 3, the intro, 
//the ending screen, room1, the death message, and the winner list

int main() {
    
    //declare variables
    int classnum;//class selection,
    bool dead=false;// used if character dies
    unsigned char x;//used to pause input for the reader
    
    srand(static_cast<unsigned int>(time(0)));
    //used for seeding randomization
    
    do {//loop for the main game, will stop if player wins
    //welcome them to the game, make them feel at home
    cout<<"Welcome to Dragon's Lair. "
            "Please expand the output window vertically."<<endl;
    cout<<"Enter any key to continue."<<endl;
    cin>>x;//to halt the advance of text
    for (x=0;x<50;x++){//used to advance the text
        cout<<endl;}
    
    //ask if they want to see the winner list
    char choice;
    cout<<"Would you like to see the survivor record? Enter 'y' to see "
            "it, enter any other key to continue with the game."<<endl;
    cin>>choice;
    if (choice=='y'){
        winners();
    }
    
    
    //ask which class they want to play
    classnum=prof();
    
    //give them the intro
    intro1(classnum);
    
    //they enter the first room
    room1(classnum);
    
    //they enter the second room
    dead=room2(classnum);
    
    //entering the last room
    if (dead==false){//if they died it doesn't run
    dead=room3(classnum);}
    
    //play 'em out, johnny
    if (dead==false){//if they lived they get the victory message
    youlive();}
    
    //if they died
    if (dead==true){
        cout<<"To quit enter 0, to try again enter any other key."<<endl;
        cin>>x;//used to halt the advance of text
        if (x==0){//if they quit, exit the program
            exit(0);
        }
        for (x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
    }
    while (dead==true);//while the player is dead, loop back to the beginning
    
    
    return 0;
}

int prof(){ //lets the user choose their class to play
    string picture;//to display the class image
    unsigned char x;
    int classnum;//whichever class they choose
    cout<<"Which class would you like to select?\n"<<endl;
    cout<<"Warrior: Can handle himself in a fight, but is slowed from heavy "
            "armor and bad at sneaking.\n"<<endl;
    cout<<"Rogue: Can sneak, is fast, but not the best at fighting.\n"<<endl;
    cout<<"Wizard: Does not sneak or fight well, has no armor, but can cast"
            " useful spells.\n"<<endl;
    do {
    cout<<"Please input 1 for warrior, 2 for rogue, or 3 for wizard.\n"<<endl;
    cin>>classnum;
        if(cin.fail()) {
            cin.clear();
            cin.ignore(256,'\n');
        }
    }
    while (classnum<1 || classnum>3);

    string prof[3][2] = {"Warrior","warrior.dat","Rogue","rogue.dat","Wizard",
    "wizard.dat"};
    if (classnum==1){
        cout<<"You have chosen "<<prof[0][0]<<endl<<endl;
        cout<<"Enter any key to continue."<<endl;
        cin>>x;//used to halt the advance of text
        for (x=0;x<50;x++){//used to advance the text
            cout<<endl;}
        ifstream warrior(prof[0][1].c_str());//opens the picture 
        while(!warrior.eof()) {//while not at end of file
            getline(warrior, picture);//get each line
            cout << picture << endl;}//output each line
        warrior.close();//close the file
    }
    if (classnum==2){
        cout<<"You have chosen "<<prof[1][0]<<endl<<endl;
        cout<<"Enter any key to continue."<<endl;
        cin>>x;//used to halt the advance of text
        for (x=0;x<50;x++){//used to advance the text
            cout<<endl;}
    ifstream rogue(prof[1][1].c_str());//opens the picture 
        while(!rogue.eof()) {//while not at end of file
            getline(rogue, picture);//get each line
            cout << picture << endl;}//output each line
        rogue.close();//close the file
    }
    if (classnum==3){
        cout<<"You have chosen "<<prof[2][0]<<endl<<endl;
        cout<<"Enter any key to continue."<<endl;
        cin>>x;//used to halt the advance of text
        for (x=0;x<50;x++){//used to advance the text
            cout<<endl;}
    ifstream wizard(prof[2][1].c_str());//opens the picture 
        while(!wizard.eof()) {//while not at end of file
            getline(wizard, picture);//get each line
            cout << picture << endl;}//output each line
        wizard.close();//close the file
    }
    
    cout<<"Enter any key to continue."<<endl;
    cin>>x;//used to halt the advance of text
    for (x=0;x<50;x++){//used to advance the text
        cout<<endl;}
    
    return (classnum);
}

void room1(int classnum){//first room in the dungeon, the entry-way
    unsigned char x;
    cout<<"Just as you enter the entrance to the dungeon, a large "
                "portcullis slams down behind you."<<endl;
    cout<<"Enter any key to continue."<<endl;
    cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
    if (classnum==1){//if they are a warrior
    cout<<"You put down your sword and shield and push against the "
            "portcullis, but to no avail."<<endl;
    cout<<"Enter any key to continue."<<endl;
    cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
    cout<<"With a sigh, you re-arm yourself and look around the room.\n"<<endl;
    cout<<"Enter any key to continue."<<endl;
    cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
    if (classnum==2){//if they are a rogue
    cout<<"As you thoroughly examine the door, you slowly start to realize"
            " that there is no lock to pick or secret door to find."<<endl;
    cout<<"Enter any key to continue."<<endl;
    cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
    cout<<"Slightly paranoid, you decide sneaking would be best.\n"<<endl;
    cout<<"Enter any key to continue."<<endl;
    cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
    if (classnum==3){//if they are a wizard
    cout<<"With your ability to read magical text, you notice the "
            "portcullis glowing with a magical inscription."<<endl;
    cout<<"Enter any key to continue."<<endl;
    cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
    cout<<"It says 'The seal can only be undone by slaying the dragon.'"
            <<endl;
    cout<<"Below that it also says 'Merlin was here.'"<<endl;
    cout<<"With an exasperated sigh, you turn around."<<endl;
    cout<<"Enter any key to continue."<<endl;
    cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
    //for all adventurers
    cout<<"The entry-way into the dungeon is old and worn, and you can hear"
            " the faint drip of water in the distance."<<endl;
    cout<<"There is a short hallway heading down to a door and what is "
            "presumably the rest of the dungeon."<<endl;
    cout<<"Since the only path ahead is forward, you decide to open the door"
            " into the next room.\n"<<endl;
    cout<<"Enter any key to continue."<<endl;
    cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
}

bool room2(int classnum){//central hub, goblin room
    string picture;//goblin picture
    unsigned char x;
    int choice, chance, result;
    bool dead=false;//player is currently alive
    //choice is for the switches, chance is for % randomizing, result for
    //the result of the chance
    cout<<"As you bash the door open, you look into the room and see a "
                "goblin slumped in front of a door.\n"
                <<endl;
    cout<<"Enter any key to continue."<<endl;
        cin>>x;//used to halt the advance of text
        for (x=0;x<50;x++){//used to advance the text
            cout<<endl;}
    ifstream goblin("goblin.dat");//opens the picture 
        while(!goblin.eof()) {//while not at end of file
            getline(goblin, picture);//get each line
            cout << picture << endl;}//output each line
        goblin.close();//close the file
    cout<<"Enter any key to continue."<<endl;
    cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
    cout<<"How do you want to deal with the goblin?\n"
                "To fight enter 1.\n"
                "To sneak by him enter 2.\n"
                "To talk enter 3.\n"<<endl;
    cin>>choice;
    do{
    if (classnum==1){//if warrior
        switch (choice){
        case 1:{//for fighting
                cout<<"With a roar you charge him.\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                chance=80;//80% chance of success
                result=random(chance);
                if (result>=100){//if successful
                   cout<<"With a squeak he wakes up and upon seeing you "
"bearing down on him, his eyes bulge and he fumbles with his shield, "
"trying to bring it up in time.\nUsing a little luck and a lot of anger, "
"you manage to bring your sword down before he can get the shield up.\n"
"You cleave the goblin from chest to groin and he messily expires "
                           "on the floor.\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
                if (result<100){//if failure
                   cout<<"With a squeak he wakes up and upon seeing you "
"bearing down on him, his eyes bulge and he fumbles with his shield, trying to "
"bring it up in time.\nAs you bear down on him, you manage to slip on a puddle"
" in the middle of the floor and fall on your face.\nWhile sliding on the "
"stone floor towards the goblin, he brings his spear down and impales you "
                           "through the back.\n"<<endl;
                   cout<<"Enter any key to continue."<<endl;
                   cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                   youdied();//player has died
                   dead=true;}
                break;}
        case 2:{//for sneaking
            cout<<"For some reason you think it would be a good idea to"
                    "try and sneak by him.\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
            chance=30;//30% chance of success
            result=random(chance);
            if (result>=100){//if successful
                cout<<"Somehow he doesn't wake up even with your full"
                        "plate clanking and banging around.\nYou "
                        "eventually make it to the door at the end of the"
                        " room.\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
            if (result<100){//if failure
                cout<<"Sneaking by him is actually working, you're quite "
                        "surprised.\nThat is, until you pass him and suddenly"
                        " see his spear erupt out of your stomach.\n"
                        "You realize that you woke him up earlier and he "
                        "was merely pretending to be asleep.\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                youdied();//player has died
                dead=true;}
                break;}
        case 3:{//for talking
            cout<<"Might as well try and talk to him. You call to him.\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
            chance=50;//50% chance of success
            result=random(chance);
            if (result>=100){//if success
                cout<<"'Hello?', you call out.\nWith a start, the goblin wakes"
                        " and upon seeing you, is confused why you haven't"
                        " yet tried to kill him.\nHe decides to get the upper"
                        " hand by stabbing at you with the spear.\n"
                        "Fortunately, you were ready for him and overpower and"
                        " slay him.\nYou decide it's best to move on into"
                        " the next room.\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
            if (result<100){//if failure
                cout<<"'Hello?', you call out.\nWith a start, the goblin wakes"
                        " and upon seeing you, is confused why you haven't"
                        " yet tried to kill him.\nHe decides to get the upper"
                        " hand by stabbing at you with the spear.\n"
                        "Unfortunately, he's faster than you and manages to"
                        " put straight steel through your insides.\nShouldn't"
                        " have trusted a goblin.\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                youdied();//player has died
                dead=true;}
            break;}
        default:{
            cout<<"Please enter 1, 2, or 3"<<endl;}
        }
    }
    if (classnum==2){//if rogue
        switch (choice){
        case 1:{//for fighting
                cout<<"Abandoning all pretense at stealth, you quickly move "
                        "in for the kill.\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                chance=50;//50% chance of success
                result=random(chance);
                if (result>=100){//if successful
                   cout<<"With a squeak he wakes up and upon seeing you "
"moving in with your dagger drawn, his eyes bulge and he fumbles for his "
"spear.\n You, however, are faster.\nWith a smirk, you gut him like a fish.\n"
"As you wipe your dagger off on his quickly expiring form, you hope that the "
                           "dragon will be just as easy.\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
                if (result<100){//if failure
                   cout<<"With a squeak he wakes up and upon seeing you "
"bearing down on him, his eyes bulge and he fumbles with his shield, trying to "
"bring it up in time.\nYou move to get around the shield but he catches you "
"in the ribs with a dagger you hadn't seen earlier.\nAs everything fades, you"
" feel small hands pulling at your coin pouch.\n"<<endl;
                   cout<<"Enter any key to continue."<<endl;
                   cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                   youdied();//player has died
                   dead=true;}
                break;}
        case 2:{//for sneaking
            cout<<"You think it best to continue sneaking.\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
            chance=80;//80% chance of success
            result=random(chance);
            if (result>=100){//if successful
                cout<<"As expected, he doesn't hear your approach.\n"
"However, it's because he fell asleep.\n With an evil grin you slit his throat"
" and take his coin purse. Hopefully the dragon proves this easy.\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
            if (result<100){//if failure
                cout<<"As expected, he doesn't hear your approach.\n"
"You thrust your dagger into his chest, but hit only steel.\nYour dagger"
" bounces off and he pulls you in closer, not missing with his dagger.\n"
"If only you'd noticed he'd been wearing armor.\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                youdied();//player has died
                dead=true;}
                break;}
        case 3:{//for talking
            cout<<"You figure he might have useful information.\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
            chance=30;//30% chance of success
            result=random(chance);
            if (result>=100){//if success
                cout<<"'Get up.', you tell him.\nHe wakes with a start and "
"says 'Please don't kill me, I'll tell you whatever you want to know.'\n"
"'Where's the loot?'\n'The dragon keeps it in his room. He sleeps on some of it"
", and the rest is just scattered around the room.'\n'Good. Now get out before"
" I change my mind.'\nHe starts scurrying out of the room.\n"
"Acting swiftly, you shank him from behind. No witnesses.\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
            if (result<100){//if failure
                cout<<"'Get up.', you tell him.\nHe wakes with a start and "
"says 'Please don't kill me, I'll tell you whatever you want to know.'\n"
"'Where's the loot?'\n'The dragon keeps it in his room. He sleeps on some of it"
", and the rest is just scattered around the room.'\n'Good. Now get out before"
" I change my mind.'\nHe starts scurrying out of the room.\nJust as he passes"
" you, you feel a knife tear into your liver.\nThe goblin laughs and says "
"'Shouldn't have trusted a goblin.'\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                youdied();//player has died
                dead=true;}
            break;}
        default:{
            cout<<"Please enter 1, 2, or 3"<<endl;}
        }
    }
        
    if (classnum==3){//if wizard
        switch (choice){
        case 1:{//for fighting
                cout<<"You begin chanting a spell to burn him to cinders."
                        "\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                chance=30;//30% chance of success
                result=random(chance);
                if (result>=100){//if successful
                   cout<<"With a squeak he wakes up and upon hearing you "
"chanting, he rushes forward.\nYou manage to complete the spell in time and a "
"ray of fire shoots from your hands into him.\nYou notice that he got a bit "
                           "close for comfort.\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
                if (result<100){//if failure
                   cout<<"With a squeak he wakes up and upon hearing you "
"chanting, he rushes forward.\nYou struggle to complete the spell in time but "
"fumble over a few of the words.\nBack-pedaling quickly, you start chanting all"
" over again.\nWith a great effort, the little goblin thrusts the spear into "
"your shoulder, causing you to lose the spell once again and allowing him "
"plenty of time to draw his dagger and gut you.\n"<<endl;
                   cout<<"Enter any key to continue."<<endl;
                   cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                   youdied();//player has died
                   dead=true;}
                break;}
        case 2:{//for sneaking
            cout<<"With your quiet robes, he shouldn't hear you "
                    "sneaking.\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
            chance=50;//50% chance of success
            result=random(chance);
            if (result>=100){//if successful
                cout<<"As you tiptoe towards him, you begin weaving a sleep"
" spell.\nWith a wiggle of your fingers, you complete the spell, putting the "
"goblin into a very deep sleep which he won't wake up from for a day or two."
                        "\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
            if (result<100){//if failure
                cout<<"As you tiptoe towards him, you begin weaving a sleep "
"spell.\nBut it's so hard to remember all the words...was it nickel? nakto? "
"nike?\nAs you're contemplating that, the goblin runs you through with his "
"spear.\nShould have paid better attention to your surroundings.\nDistracted "
"Casting kills over 10 casters per year.\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                youdied();//player has died
                dead=true;}
                break;}
        case 3:{//for talking
            cout<<"You figure he might have useful information.\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
            chance=80;//80% chance of success
            result=random(chance);
            if (result>=100){//if success
                cout<<"'Greetings.' you say.\nThe goblin awakes with a start "
"and looks around, finally settling on you.\nWith your quick wit and big words "
"you quickly charm him into becoming a friend of yours.\nYou pull out a "
"sleeping potion and suggest a toast to celebrate your newfound friendship.\n"
"As you look at the passed out goblin, you chuckle to yourself and remember all"
" those sleeping potions you drank to inoculate yourself against their "
"effects.\nGuess it finally paid off.\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
            if (result<100){//if failure
                cout<<"'Greetings.' you say.\nThe goblin awakes with a start "
"and looks around, finally settling on you.\nWith your quick wit and big words "
"you seemingly charm him into becoming a friend of yours.\nYou pull out a "
"sleeping potion and suggest a toast to celebrate your newfound friendship.\n"
"As you wait for the goblin to fall asleep, everything starts going dark.\n"
"That little bastard probably slipped something into your drink when you "
"weren't looking.\nShouldn't have trusted a goblin.\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                youdied();//player has died
                dead=true;}
            break;}
        default:{
            cout<<"Please enter 1, 2, or 3"<<endl;}
        }}
    }
    while (choice<1 || choice>3);
 return(dead);
}

bool room3(int classnum){//third room in the dungeon, loot and dragon
    string picture;//for the dragon picture
    unsigned char x;
    int choice, chance, result;
    bool dead=false;
    //choice is for the switches, chance is for % randomizing, result for
    //the result of the chance
    cout<<"As you open the door, you hear a faint rumbling.\nThen silence...\n"
"Then rumbling again. As your eyes adjust to the darkness, you see one of the "
"most fearsome monsters to terrorize the land and sky. A dragon.\nUnder the "
"dragon sits the largest pile of gold and gems you've ever seen.\nThere also "
"seems to be some kind of air draft coming from behind it.\nIt's most likely "
"another way out."<<endl;
    cout<<"Enter any key to continue."<<endl;
        cin>>x;//used to halt the advance of text
        for (x=0;x<50;x++){//used to advance the text
            cout<<endl;}
    ifstream dragon("dragon.dat");//opens the picture 
        while(!dragon.eof()) {//while not at end of file
            getline(dragon, picture);//get each line
            cout << picture << endl;}//output each line
        dragon.close();//close the file
    cout<<"Enter any key to continue."<<endl;
    cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
    cout<<"How should you proceed?\n"
                "To go for the loot enter 1.\n"
                "To go around him and attack from behind enter 2.\n"
                "To challenge him to honorable combat enter 3.\n"<<endl;
    cin>>choice;
    do{
    if (classnum==1){//if warrior
        switch (choice){
        case 1:{//for looting
                cout<<"You decide that that gold could best be spent improving "
    "the town, maybe even hiring guards to help against a possible dragon\n "
    "attack that may occur in the future which is in no way related to pissing "
                        "a dragon off by taking its stuff.\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                chance=80;//80% chance of success
                result=random(chance);
                if (result>=100){//if successful
                   cout<<"You sheathe your sword and put your shield on your "
"back\nTaking a couple of deep breaths, you sprint for a small chest on the "
"edge of the treasure pile.\nThe dragon wakes at the squeal of metal on metal "
"and turns towards you.\nYou grab the chest just as it roars and you feel heat "
"blossoming on your back.\nLuckily, your ancient shield is enchanted against "
"dragonfire and protects you against the worst of it.\nYou just manage to run "
"out of the cave exit, chest full of diamonds and rubies in hand.\nIt should at"
" least be enough to pay some wandering adventurers enough to kill it for "
                           "you.\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
                if (result<100){//if failure
                   cout<<"You sheathe your sword and put your shield on your "
"back\nTaking a couple of deep breaths, you sprint for a small chest on the "
"edge of the treasure pile.\nThe dragon wakes at the squeal of metal on metal "
"and turns towards you.\nYou grab the chest just as it roars and you feel heat "
"blossoming on your back.\nLuckily, your ancient shield is enchanted against "
"dragonfire\nToo bad that the dragon also breathed its torrent of flame onto "
              "your legs, which are now melting.\n"<<endl;
                   cout<<"Enter any key to continue."<<endl;
                   cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                   youdied();//player has died
                   dead=true;}
                break;}
        case 2:{//for attacking from behind
            cout<<"You know it would be more honorable to face the dragon down "
         "in glorious combat, but attacking from behind is healthier.\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
            chance=50;//50% chance of success
            result=random(chance);
            if (result>=100){//if successful
                cout<<"You pick up a nearby rock and throw it towards the mouth"
" of the cave exit behind the dragon.\nIt's head whips around at the source of "
"the noise, thinking it's being invaded from the cave mouth.\nThis gives you "
"exactly the chance you needed.\nWith a great leap and mighty stab, you manage "
"to stab your ancient and enchanted sword into the foul beast's neck just as "
"it turns back around.\nIt's death throes shake the entire chamber and it's "
"all you can do to get out before it collapses behind you.\nYou didn't manage"
" to grab any loot, but the villagers are safe. At least from this threat."
                        "\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
            if (result<100){//if failure
                cout<<"You pick up a nearby rock and throw it towards the mouth"
" of the cave exit behind the dragon.\nIt's head whips around at the source of "
"the noise, thinking it's being invaded from the cave mouth.\nThis gives you "
"exactly the chance you needed.\nWith a great leap and mighty stab, you try "
"to stab your ancient and enchanted sword into the foul beast's neck just as "
"it turns back around.\nBut your steel glances off its tough hide and leaves "
"you wildly overextended.\nThis gives the dragon an opportunity to bite you in"
                        " half.\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                youdied();//player has died
                dead=true;}
                break;}
        case 3:{//for the challenging
            cout<<"Well, the story would be better if you faced the beast in"
                    " a manly 1v1.\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
            chance=30;//30% chance of success
            result=random(chance);
            if (result>=100){//if success
                cout<<"'Wake up and face me!' you bellow into the cavern.\nThe"
" dragon stirs, and after taking a second to get its bearings, lunges for you."
"\nYou were ready for that and by the time its jaws snap on empty air, you've "
"already braced and started swinging your sword in an overhand two-handed "
"grip.\nIt tries to pull back but your sword catches it under a scale and "
"slices through a third of its neck before its yanked out of your hands.\nThe "
"dragon starts going into seizures and dies, you must have severed its spine."
"\nAt least now the people of Varrock won't have to worry about this plaguing "
                        "them any longer."<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
            if (result<100){//if failure
                cout<<"'Wake up and face me!' you bellow into the cavern.\nThe"
" dragon stirs, and after taking a second to get its bearings, lunges for you."
"\nYou were ready for that and by the time its jaws snap on empty air, you've "
"already braced and started swinging your sword in an overhand two-handed "
"grip.\nIt tries to pull back but your sword catches it under a scale and "
"it bounces off the tough hide.\nJust before you can once again pick up your "
"shield, the dragon catches you in it flame breath, cooking you alive in your "
           "armor.\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                youdied();//player has died
                dead=true;}
            break;}
        default:{
            cout<<"Please enter 1, 2, or 3"<<endl;}
        }
    }
    if (classnum==2){//if rogue
        switch (choice){
        case 1:{//for looting
                cout<<"Why fight a dragon? You're only here for its stuff "
                        "anyways.\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                chance=50;//50% chance of success
                result=random(chance);
                if (result>=100){//if successful
                   cout<<"Even as you creep forward towards a particularly "
"gilded chest, you can't take your eyes off the massive claws jealously "
"guarding the hoard.\nOh so carefully pulling the chest out, a few coins slide"
" down the mound.\nSweating, you look over at the dragon. Thankfully, it "
"appears to still be asleep.\nCarefully, you tiptoe out the back of the cave as"
" quickly as you can while maintaining silence, scooping to pick up a few "
                           "choice gems along the way.\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
                if (result<100){//if failure
                   cout<<"Even as you creep forward towards a particularly "
"gilded chest, you can't take your eyes off the massive claws jealously "
"guarding the hoard.\nOh so carefully pulling the chest out, a few coins slide"
" down the mound.\nJust as you think the worst of it is over, you notice a "
"chalice tipping over and bouncing off the cave floor and rolling.\nOh no.\n"
"The last thing passing through your mind is a dragon's fang.\n"
                           <<endl;
                   cout<<"Enter any key to continue."<<endl;
                   cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                   youdied();//player has died
                   dead=true;}
                break;}
        case 2:{//for attacking from behind
            cout<<"You think it best to backstab the problem away.\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
            chance=30;//30% chance of success
            result=random(chance);
            if (result>=100){//if successful
                cout<<"You see a black javelin with a wicked-looking barb on "
"the end of it sitting on the side of the mound, like it was a recent addition."
"\nYou go over and pick it up, thinking it'll do the trick. It certainly looks "
"nasty enough.\nClimbing partway up the wall, you jump off, landing on the "
"dragon's neck and jabbing the spear down into its head at the back of its "
"skull, just under the bone\nThe dragon tries to roar but starts twitching and "
"then goes silent.\nWell now you have all this treasure to yourself.\nCome to "
"think of it, you wonder how much you could sell the dragon's body for...\n"
<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
            if (result<100){//if failure
                cout<<"You see a black javelin with a wicked-looking barb on "
"the end of it sitting on the side of the mound, like it was a recent addition."
"\nYou go over and pick it up, thinking it'll do the trick. It certainly looks "
"nasty enough.\nClimbing partway up the wall, you jump off, attempting to land "
"on its neck but instead misjudging the fall and landing just in front of its "
"mouth and waking it up.\nAs you contemplate where you went wrong, at least "
"you're sure that it'll be a quick death.\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                youdied();//player has died
                dead=true;}
                break;}
        case 3:{//for glorious 1v1 combat
            cout<<"You must have gone insane in the last 5 minutes because "
            "you're about to challenge a dragon to 1v1 combat.\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
            chance=80;//80% chance of success
            result=random(chance);
            if (result>=100){//if success
                cout<<"Bellowing out a challenge for some reason, you watch the"
" dragon slowly lift its head, wondering how a crazy person got past its elite "
"goblin-guard.\n'You work for me now. Go tell the village below to bring a "
"tribute once a month. Do not disappoint me. I will find you.'\nStammering a "
"reply, you decide not to argue and leave out of the back of the cave.\nYou "
"might not have much loot, but you have your life, and a good story.\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
            if (result<100){//if failure
                cout<<"Bellowing out a challenge for some reason, you watch the"
" dragon slowly lift its head, wondering how a crazy person got past its elite "
"goblin-guard.\n'You work for me now. Go tell the village below to bring a "
"tribute once a month. Do not disappoint me. I will find you.'\nStammering a "
"reply, you say that you don't live in the area, and that you know a guy who "
"would be much better suited for the position...\nAnd that's when it decides "
"you aren't worth the trouble and breathes fire onto you.\nMaybe don't argue "
                        "with a dragon next time?\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                youdied();//player has died
                dead=true;}
            break;}
        default:{
            cout<<"Please enter 1, 2, or 3"<<endl;}
        }
    }
        
    if (classnum==3){//if wizard
        switch (choice){
        case 1:{//for looting
                cout<<"You decide that gold will get you all the spell "
                        "components you'll ever need.\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                chance=30;//30% chance of success
                result=random(chance);
                if (result>=100){//if successful
                   cout<<"You swiftly and silently cast a spell to levitate a "
"few of the larger chests out of the cave with you.\nEverything goes better "
"than expected, you're able to sneak out with the chests with the dragon "
                       "being none the wiser.\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
                if (result<100){//if failure
                   cout<<"You swiftly and silently cast a spell to levitate a "
"few of the larger chests out of the cave with you.\nEverything goes better "
"than expected until you notice that accidentally casted levitate on one of the"
" dragon's claws.\nYou almost managed to finish the teleport spell when it "
                        "bites you in half.\n"<<endl;
                   cout<<"Enter any key to continue."<<endl;
                   cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                   youdied();//player has died
                   dead=true;}
                break;}
        case 2:{//for backstabbing
            cout<<"Dragons are notoriously resistant to magic, maybe you can "
                    "find a weakness around back.\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
            chance=80;//80% chance of success
            result=random(chance);
            if (result>=100){//if successful
                cout<<"As you start moving around the sleeping monster, you "
"notice the stalactites hanging overhead and you get an idea.\nYou begin "
"quickly casting a fireball, aiming at the base of the stalactite hanging "
"overhead.\nHoping to finish before the dragon wakes up, you continue chanting "
"furiously.\nWith a relieved command word, you send a little pea of fire "
"shooting into the ceiling, dislodging the largest of the stalactites and not "
"a few of the smaller ones.\nThey come crashing down onto the dragon, piercing "
"its tough hide and armored scales.\nLooks like you'll finally have those spell"
      " components you needed.\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
            if (result<100){//if failure
                cout<<"As you start moving around the sleeping monster, you "
"notice the stalactites hanging overhead and you get an idea.\nYou begin "
"quickly casting a fireball, aiming at the base of the stalactite hanging "
"overhead.\nHoping to finish before the dragon wakes up, you continue chanting "
"furiously.\nWith a relieved command word, you send a little pea of fire "
"shooting into the ceiling, dislodging the largest of the stalactites and not "
"a few of the smaller ones.\nThey come crashing down onto the dragon, piercing "
"its tough hide and armored scales.\nUnfortunately, they weren't quite mortal "
"and that is the angriest looking dragon you've ever seen.\nDoesn't look like "
"you'll have time to even attempt another spell before you're killed horribly."
                        "\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                youdied();//player has died
                dead=true;}
                break;}
        case 3:{//for challenging
            cout<<"Having gone slightly insane, you think challenging a dragon"
             "might be a good idea.\nYou were getting too old anyways.\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
            chance=50;//50% chance of success
            result=random(chance);
            if (result>=100){//if success
                cout<<"As soon as you open your mouth, you're cut off by a deep"
" bass rumble.\n'Sh. Sh-sh-sh. Sh.', the dragon silences you.\n'Cast an "
"illusion on my scales to turn them gold. I want to have some fun with a "
"caravan later. I'll give you a ruby and promise to not knock your tower over, "
"the one over by Varrock, yeah I know who you are.'\nWell, it might not be the "
       "treasure you hoped for, but at least you lived. So far.\n"<<endl;
            cout<<"Enter any key to continue."<<endl;
            cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
            if (result<100){//if failure
                cout<<"As soon as you open your mouth, you're cut off by a deep"
" bass rumble.\n'Sh. Sh-sh-sh. Sh.', the dragon silences you.\n'Cast an "
"illusion on my scales to turn them gold. I want to have some fun with a "
"caravan later. I'll give you a ruby and promise to not knock your tower over, "
"the one over by Varrock, yeah I know who you are.'\n'But I don't know any "
"illusion spells!' yo say.\n'Oh. Well I guess you're of no use to me then.'\n"
"Should have brushed up on your illusion I guess.\n"<<endl;
                cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
                youdied();//player has died
                dead=true;}
            break;}
        default:{
            cout<<"Please enter 1, 2, or 3"<<endl;}
        }}
    }
    while (choice<1 || choice>3);
 return(dead); 
}

void intro1(int classnum){
    unsigned char x;
    if (classnum==1){
        cout<<"You are Cecil, a local knight tasked with defending the nearby"
                " village of Varrock."<<endl;
        cout<<"You've been hearing rumors of a dragon attacking caravans"
                " heading into town and have decided to do something about it "
                "before he decides to attack Varrock."<<endl;
        cout<<"So, you grabbed your full plate, and trusty sword and shield "
                "and headed off to the dragon's lair.\n"<<endl;
    cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
    if (classnum==2){
        cout<<"Locally, you are known by the name Kain. Some towns call you "
                "Robin, others know you as Jeremiah."<<endl;
        cout<<"On the caravan into town, you overheard some of the caravan"
                " guards nervously discussing the possibility of a dragon"
                " attack."<<endl;
        cout<<"Where there's a dragon, there's loot."<<endl;
        cout<<"With that in mind, you headed off to the dragon's lair...\n"
                <<endl;
    cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
    if (classnum==3){
        cout<<"You have lived for 100 years, yet you don't look a day over 67."
        <<endl;
        cout<<"You are Elminster, a wizard of some renown, on the verge of "
                "creating a great new spell."<<endl;
        cout<<"The only problem is, you need some rather rare spell components"
                " for it."<<endl;
        cout<<"While in town, you overheard some merchants talking about "
                "dragon attacks from nearby. A dragon would be perfect."<<endl;
        cout<<"Their entire body is usable for spells, plus you can sell"
                " whatever you don't use."<<endl;
        cout<<"So with this in mind, you casted some protective spells and"
                " headed off towards the dragon's lair.\n"<<endl;
    cout<<"Enter any key to continue."<<endl;
                cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}}
}

void youlive(){
    char record[4]="AAA";
    string picture;//for the death message
    unsigned char x;
    ifstream alive("alive.dat");//opens the picture 
        while(!alive.eof()) {//while not at end of file
            getline(alive, picture);//get each line
            cout << picture << endl;}//output each line
        alive.close();//close the file
        cout<<"Enter any key to continue."<<endl;
                   cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
    cout<<"Good job, you made it to the end."<<endl;//end message
    ofstream out ("winners.dat", ios::app);
    cout<<"Please enter 3 letters to track yourself in the survivor records."
            <<endl;
    cin>>record;//getting the initials
    out<<endl<<record;
    out.close();//closing the file
}

int random(int chance){//randomizing chance
    int result;
    result=rand()%100+chance;
    return (result);
}

void youdied(){
    string picture;//for the death message
    unsigned char x;
    ifstream dead("dead.dat");//opens the picture 
        while(!dead.eof()) {//while not at end of file
            getline(dead, picture);//get each line
            cout << picture << endl;}//output each line
        dead.close();//close the file
        cout<<"Enter any key to continue."<<endl;
                   cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl;}
}

void winners(){
    char choice;
    int i=0;
    const int SIZE=100;
    unsigned char x;
    string array[SIZE];
    string winner;//each individual person who has won
    cout<<endl<<"Enter 'c' to see the list chronologically, 'a' to see the "
    "list sorted alphabetically,"<<endl<<" or 's' to search for someone."<<endl;
    cin>>choice;
    do {
    ifstream winners("winners.dat");//opens the file
    while(!(winners.eof())) {//while not at end of file
        getline(winners, winner);    
        array[i]=winner;
        if (choice=='c'){cout<< winner << endl;}//if they pick chronological
        if( i==0 ) { i++; continue; } 
        if (array[i]<array[i-1]){//alphabetize the winners
            string temp;//cant use exclusively or with strings
            temp=array[i];
            array[i]=array[i-1];
            array[i-1]=temp;
        }
        i++;
    }
    if (choice=='a'){//if they pick alphabetize
        for (int j=0;j<i;j++){
            cout<<array[j]<<endl;}//output sorted array
    }
    if (choice=='s'){//if they pick search
        int q;
        string search;
        cout<<"What name would you like to search for? Enter 3 letters"<<endl;
        cin>>search;
        for (q=0;q<SIZE;q++){
            if (array[q]==search){
                cout<<search<<" did survive the Dragon's Lair."<<endl;
                break;        
            } 
        }
        if (q==SIZE){
            cout<<"That name could not be found."<<endl;
        }
    }
    winners.close();//close the file
    } while (choice!='c'&&choice!='a'&&choice!='s');
    cout<<"Enter any key to continue."<<endl;
    cin>>x;//to halt the advance of text
    for (int x=0;x<50;x++){//used to advance the text
        cout<<endl<<endl;}
}